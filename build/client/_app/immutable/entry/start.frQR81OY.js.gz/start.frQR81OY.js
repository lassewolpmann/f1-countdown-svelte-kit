import{l as o,s as r}from"../chunks/Bh9F3YOw.js";export{o as load_css,r as start};
